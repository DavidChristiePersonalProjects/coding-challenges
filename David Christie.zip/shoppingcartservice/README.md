### About
This project is a RESTful shopping cart service and was created using NetBeans 8.2/

### Getting Started
To launch the service navigate to \target and execute shoppingcartservice-0.0.1-SNAPSHOT.jar, this will attempt to launch the service using port 8080.
Note: the mock api service must be running on post 8081.

### Testing
To simplify testing a mock UI is available in \MockViews.  To use it load the file MockUI.html into a browser.
In addition a collection of requests for testing the service has been exported from Postman and is available in \PostmanRequests