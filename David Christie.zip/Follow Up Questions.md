1. In total I spent roughly about 20 hours on the test.

2. If I had more time, I would have added more extensive unit testing.  In addition, I would have added some CSS to enhance the front end experience and outputted more details on the checkout basket in order to make it more readable.

3. I would provide API calls for getting promotion details.

4. Getting the http requests to execute in the correct order using Vanilla JavaScript.

5. Overall it was a good experience and it gave me an oppertunity to practice several skills.

